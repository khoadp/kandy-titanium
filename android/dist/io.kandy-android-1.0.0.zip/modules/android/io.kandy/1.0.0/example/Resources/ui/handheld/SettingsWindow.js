function SettingsWindow(Kandy) {
	var self = Ti.UI.createWindow({
		title : L('settings'),
		backgroundColor : 'white'
	});

	return self;
};

module.exports = SettingsWindow;
